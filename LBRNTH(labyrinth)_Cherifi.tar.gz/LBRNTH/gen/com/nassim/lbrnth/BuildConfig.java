/** Automatically generated file. DO NOT MODIFY */
package com.nassim.lbrnth;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}